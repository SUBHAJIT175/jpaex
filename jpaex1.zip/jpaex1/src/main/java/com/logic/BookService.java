package com.logic;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class BookService {
@Autowired
private BookRepository bookRepository;
@Autowired
private ReviewsRepository reviewsRepository;
public boolean save(List<Book> books) {
	boolean isSaved=false;
	 bookRepository.saveAll(books);
	 books.forEach(book->{
		 List<Reviews> reviewsList=book.getReviews();   
		 reviewsList.forEach(review->{review.setBook(book);reviewsRepository.save(review);});
		 //reviewsRepository.saveAll(book.getReviews())
		 });
	 isSaved=true;
	 return isSaved;
    
}
public Book findBookDetails(String title) {
	
	Book book=bookRepository.findByTitle(title);
	List<Reviews> reviews=reviewsRepository.findByBookTitle(title);
	
	System.out.println(book);
	return book;
}
}
