package com.logic;

import java.util.Date;
import java.util.List;


import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import javax.persistence.OneToMany;



import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonManagedReference;

import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.CascadeType;
import javax.persistence.Column;
@Entity
@Data
@NoArgsConstructor
//@EqualsAndHashCode(exclude = "reviews")
@JsonIgnoreProperties({"id"})
public class Book {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(nullable=true)
private long id;

private String title;
private String author;
@JsonFormat
(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
private Date publishedDate;
private Long isbn;
@OneToMany(fetch = FetchType.LAZY,mappedBy = "book")
@JsonManagedReference
private List<Reviews> reviews;
/*@Embedded
 */
/*public Book() {}
public Book(long id, String title, String author, Date publishedDate, Long isbn, List<Reviews> reviews) {
	super();
	this.id = id;
	this.title = title;
	this.author = author;
	this.publishedDate = publishedDate;
	this.isbn = isbn;
	this.reviews = reviews;
	this.reviews.forEach(review->review.setBook(this));
	System.out.println("Id is:"+id);
}*/
@Override
public String toString() {
	return "Book [id=" + id + ", title=" + title + ", author=" + author + ", publishedDate=" + publishedDate + ", isbn="
			+ isbn + ", reviews=" + reviews + "]";
}


}
