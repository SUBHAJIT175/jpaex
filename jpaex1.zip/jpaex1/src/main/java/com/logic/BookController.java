package com.logic;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

@RestController
//@RequestMapping("/books")
public class BookController {
	@Autowired
	private BookService bookService;
	
	@ModelAttribute
	public void provideStudentId(Model model){
	    model.addAttribute("bookId", new Long(1));
	   
	}
	@ModelAttribute
	public void provideReviewId(Model model){
	    model.addAttribute("reviewId", new Long(1));
	}
	@GetMapping(path="/find")
	@ResponseBody
	public Book findBookDetails(@RequestParam String title) {
	
			 ObjectMapper mapper = new ObjectMapper();
				TypeReference<List<Book>> typeReference = new TypeReference<List<Book>>(){};
				InputStream inputStream = TypeReference.class.getResourceAsStream("/json/test.json");
				Book b=null;
				try {
					List<Book> book = mapper.readValue(inputStream,typeReference);
					bookService.save(book);
					System.out.println("Books Saved!");
					//issaved=true;
					 b=bookService.findBookDetails(title);	
				} catch (IOException e){
					System.out.println("Unable to save books: " + e.getMessage());
				}
		return b;
	}
}
