package com.logic;

import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
/*@RepositoryRestResource(collectionResourceRel="book",path="book")*/
public interface BookRepository extends JpaRepository<Book, Long> {
	Page<Book> findById(Long id, Pageable pageable);
	 Book findByTitle(String title);
}
