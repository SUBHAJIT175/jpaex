package com.logic;

import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ReviewsRepository  extends JpaRepository<Reviews, Long> {
	 Page<Reviews> findByBookId(Long bookId, Pageable pageable);
	    Optional<Reviews> findByIdAndBookId(Long id, Long bookId);
	   List<Reviews> findByBookTitle(String bookTitle);

}
