package com.logic;

import java.util.Date;

import javax.persistence.Embeddable;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import javax.persistence.CascadeType;
import javax.persistence.Column;

@Entity
@Data
@Embeddable
@JsonIgnoreProperties({"id"})
@NoArgsConstructor 
public class Reviews {

@Id
@GeneratedValue(strategy = GenerationType.AUTO)
@Column(nullable=true)
private long id;
private String reviewerName;
private String content;
private float rating;
@JsonInclude(value= JsonInclude.Include.NON_EMPTY)
@JsonFormat
(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
private Date publishedDate;	
/*@ManyToOne(fetch = FetchType.LAZY, optional = false)
@JoinColumn(name = "id", nullable = false)*/

@ManyToOne(fetch = FetchType.LAZY)
//@JoinColumn(name="bookId",referencedColumnName="id", insertable=false, updatable=false)
@JoinColumn(name = "id1",referencedColumnName="id")
@JsonBackReference
private Book book;
/*public Reviews() {}
public Reviews(long id, String reviewerName, String content, float rating, Date publishedDate, long id1) {
	super();
	this.id = id;
	this.reviewerName = reviewerName;
	this.content = content;
	this.rating = rating;
	this.publishedDate = publishedDate;
	
	this.book = id1;
	System.out.println("Id is:"+id);

}*/

@Override
public String toString() {
	return "Reviews [id=" + id + ", reviewerName=" + reviewerName + ", content=" + content + ", rating=" + rating
			+ ", publishedDate=" + publishedDate + "]";
}

}
