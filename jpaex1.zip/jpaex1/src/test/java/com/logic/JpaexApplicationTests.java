package com.logic;

import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;

import java.net.URI;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONObject;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.skyscreamer.jsonassert.JSONAssert;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;

import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.web.util.UriComponentsBuilder;

import com.google.gson.Gson;

import org.apache.log4j.AppenderSkeleton;
import org.apache.log4j.Level;
import org.apache.log4j.spi.LoggingEvent;

@RunWith(SpringRunner.class)
/*@ContextConfiguration(classes=JpaexApplication.class)
@WebMvcTest(value = BookService.class)*/
@SpringBootTest(webEnvironment=SpringBootTest.WebEnvironment.RANDOM_PORT)
@AutoConfigureMockMvc
//@DataJpaTest
public class JpaexApplicationTests {

	/*@Autowired
	private MockMvc mockMvc;*/
	@MockBean
	private BookService bookService;
	   @Autowired
	    private TestRestTemplate restTemplate;
	   @LocalServerPort
	    int randomServerPort;
	@Test
	public void findBookDetailsTest() throws Exception {
/*		Mockito.when(
				bookService.findBookDetails("Java book")).thenReturn(true);
		RequestBuilder requestBuilder = MockMvcRequestBuilders.get(
				"/find").accept(
				MediaType.APPLICATION_JSON);
		
		JSONObject actual = new JSONObject();
		
		MvcResult result = mockMvc.perform(requestBuilder).andReturn();*/
	/*	final Logger logger = LogManager.getLogger();
		logger.info(result.getResponse()
				.getContentAsString());*/
      //  String expected= "{title: Java book, author: Ronald, publishedDate: 2019-02-01, isbn: 857300923712,  reviews: [{reviewerName: Johnson, content: Books for advance programmer, rating: 3.0,publishedDate: 2019-03-02}, {reviewerName: Mike, content: Nice topics,rating: 4.5 }]}";
/*   String expected= "{"+
    "title: Java,"+
    "author: Ronald,"+
    "publishedDate: 2019-02-01,"+
    "isbn: 857300923712,"+
    "reviews: ["+
      "{"+
        "reviewerName: Johnson,"+
        "content: Books,"+
        "rating: 3.0,"+
        "publishedDate: 2019-03-02"+
     " },"+
     "{"+
        "reviewerName: Mike,"+
        "content: Nice,"+
        "rating: 4.5"+
      "}"+
    "]"+
  "}";*/
		 String bookInJson=" {\n" + 
				"    \"title\": \"Java book\",\n" + 
				"    \"author\": \"Ronald\",\n" + 
				"    \"publishedDate\": \"2019-02-01\",\n" + 
				"    \"isbn\": \"857300923712\",\n" + 
				"    \"reviews\": [\n" + 
				"      {\n" + 
				"        \"reviewerName\": \"Johnson\",\n" + 
				"        \"content\": \"Books for advance programmer\",\n" + 
				"        \"rating\": 3.0,\n" + 
				"        \"publishedDate\": \"2019-03-02\"\n" + 
				"      },\n" + 
				"      {\n" + 
				"        \"reviewerName\": \"Mike\",\n" + 
				"        \"content\": \"Nice topics\",\n" + 
				"        \"rating\": 4.5\n" + 
				"      }\n" + 
				"    ]\n" + 
				"  }";
		 HttpHeaders headers = new HttpHeaders();
		 headers.set("Accept", MediaType.APPLICATION_JSON_VALUE);
		 final String baseUrl = "http://localhost:"+randomServerPort+"/find";
		    URI uri = new URI(baseUrl);
		    String title="Java book";
		 UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(baseUrl)
			        .queryParam("title", title);
		 HttpEntity<?> entity = new HttpEntity<>(headers);

		 HttpEntity<Book> response = restTemplate.exchange(
		         builder.toUriString(), 
		         HttpMethod.GET, 
		         entity, 
		         Book.class);
            Assert.assertEquals(false, response.hasBody());
        	  }

	}


